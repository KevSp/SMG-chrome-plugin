## Goals

SMG will have plugins available for several browsers. Most of the code in those plugins should be reused.

This project is the code shared between all plugins.

## Api

This project exposes one file `smg_web.js`. This file exposes three functions main functionalities

1. The `bool site_supported(string url, HTMLElement document)` function. This function lets you know if a given site is supported or not
2. The `function title get_identifier(string url, HTMLElement document)` function. This function returns an identifier function based on the page that was passed. An identifier function will find the title of the song currently playing by searching the current page, it will return "no song currently playing" if no song was playing. Additionally, it will throw an exception if it was unable to extract the song's title from the website for whatever reason.
3. The `string prepare_for_sending(Object identifier_result)` function. This function formats the result from an identifier to be sent to the SMG desktop application.

```js
var url = tab.url;
var document = tab.document; // the document element of the page
if (smg.site_supported(url, tab.document)) {
    var identifier = smg.get_identifier(url, document);
    setInterval(function () {
    	// get the song
    	var song = smg.prepare_for_sending(identifier());
    	// send it
    	websocket.send(song);
    }, )
} else {
  // notify user site is not supported
}
```

